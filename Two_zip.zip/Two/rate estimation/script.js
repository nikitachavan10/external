const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const phone = document.getElementById('phone'); 
const password = document.getElementById('password');
const password2 = document.getElementById('password2');
const table = document.getElementById('table');
const tableBody = document.getElementById('table-body');

function showError(input, message) {
    const formControl = input.parentElement;
    formControl.className = 'form-control error';
    const small = formControl.querySelector('small');
    small.innerText = message;
}

function showSuccess(input) {
    const formControl = input.parentElement;
    formControl.className = 'form-control success';
}

function checkEmail(input) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if (re.test(input.value.trim())) {
        showSuccess(input);
    } else {
        showError(input, 'Email is not valid');
    }
}

function checkPhone(input) {
    const phoneRegex = /^\d{10}$/;
    if (phoneRegex.test(input.value.trim())) {
        showSuccess(input);
    } else {
        showError(input, 'Mobile number must be 10 digits');
    }
}


function checkRequired(inputArr) {
    let isRequired = false;
    inputArr.forEach(function(input) {
        if (input.value.trim() === '') {
            showError(input, `${getFieldName(input)} is required`);
            isRequired = true;
        } else {
            showSuccess(input);
        }
    });

    return isRequired;
}

function checkLength(input, min, max) {
    if (input.value.length < min) {
        showError(
            input,
            `${getFieldName(input)} must be at least ${min} characters`
        );
    } else if (input.value.length > max) {
        showError(
            input,
            `${getFieldName(input)} must be less than ${max} characters`
        );
    } else {
        showSuccess(input);
    }
}

function checkPasswordsMatch(input1, input2) {
    if (input1.value !== input2.value) {
        showError(input2, 'Passwords do not match');
    }
}

function getFieldName(input) {
    return input.id.charAt(0).toUpperCase() + input.id.slice(1);
}

form.addEventListener('submit', function(e) {
    e.preventDefault();

    if (checkRequired([username, email, password, password2])) {
        checkLength(username, 3, 15);
        checkLength(password, 6, 25);
        checkEmail(email);
        checkPhone(phone);
        checkPasswordsMatch(password, password2);

        table.classList.remove('hidden');
    }

});
form.addEventListener('submit', function(e) {
    e.preventDefault();

    const inputs = [username, email, phone, password, password2];
    let hasErrors = false;

    inputs.forEach(function(input) {
        if (input.value.trim() === '') {
            showError(input, `${getFieldName(input)} is required`);
            hasErrors = true;
        } else {
            showSuccess(input);
        }
    });

    if (hasErrors) {
        // There are errors in the form, so do not display the table
        table.classList.add('hidden');
        return;
    }

    checkLength(username, 3, 15);
    checkLength(password, 6, 25);
    checkEmail(email);
    checkPhone(phone);
    checkPasswordsMatch(password, password2);

    // Check if any of the inputs have errors after additional validation
    const additionalErrors = form.querySelectorAll('.error');
    if (additionalErrors.length > 0) {
        // There are errors in the form, so do not display the table
        table.classList.add('hidden');
        return;
    }

    // All fields have passed validation, so display the table
    table.classList.remove('hidden');

    // Create a new row in the table to display form data
    const newRow = document.createElement('tr');
    const usernameCell = document.createElement('td');
    const emailCell = document.createElement('td');
    const phoneCell = document.createElement('td');

    // Set the cell values to the form input values
    usernameCell.textContent = username.value.trim();
    emailCell.textContent = email.value.trim();
    phoneCell.textContent = phone.value.trim();

    // Append cells to the row
    newRow.appendChild(usernameCell);
    newRow.appendChild(emailCell);
    newRow.appendChild(phoneCell);

    // Append the row to the table body
    tableBody.appendChild(newRow);

    // Clear form inputs after submission
    form.reset();
});

