package com.example.recyclerviewdemo2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.jetbrains.annotations.NotNull;

public class PostRecyclerAdapter extends RecyclerView.Adapter<PostRecyclerAdapter.PostViewHolder> {
    Context c;
    String data[];

    public PostRecyclerAdapter(Context c, String[] data) {
        this.c = c;
        this.data = data;
    }

    @NonNull
    @NotNull
    @Override
    public PostRecyclerAdapter.PostViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(c).inflate(R.layout.post_layout,null);
        return new PostViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull PostRecyclerAdapter.PostViewHolder holder, int position) {
        holder.b1.setText(data[position]);
        holder.b2.setText("Ok");
        holder.t1.setText("Go ahead");

        holder.b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                holder.b1.setText("Button clicked");
            }
        });

    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class PostViewHolder extends RecyclerView.ViewHolder {
        Button b1, b2;
        TextView t1;
        public PostViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            b1 = itemView.findViewById(R.id.button1);
            b2 = itemView.findViewById(R.id.button2);
            t1 = itemView.findViewById(R.id.textView1);
        }
    }
}
