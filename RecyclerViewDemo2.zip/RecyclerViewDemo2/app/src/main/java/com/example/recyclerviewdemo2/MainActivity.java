package com.example.recyclerviewdemo2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv = findViewById(R.id.postRecyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        String[] data = {"one", "two", "three", "four", "five", "six", "seven"};
        PostRecyclerAdapter pa = new PostRecyclerAdapter(this, data);
        rv.setAdapter(pa);
    }
}