package com.example.asynctask;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView resultTextView;
    private Button startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultTextView = findViewById(R.id.resultTextView);
        startButton = findViewById(R.id.startButton);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the background task
                MyAsyncTask asyncTask = new MyAsyncTask();
                asyncTask.execute();
            }
        });
    }

    // Inner class representing the AsyncTask
        private class MyAsyncTask extends AsyncTask<Void, Void, String> {
        @Override
        protected void onPreExecute() {
            // This method is executed on the UI thread before starting the background task
            super.onPreExecute();
            resultTextView.setText("Loading...");
        }

        @Override
        protected String doInBackground(Void... params) {
            // Perform the background task here
            // This method is executed on a separate background thread
            // Simulate a time-consuming task
            try {
                Thread.sleep(3000); // Wait for 3 seconds to simulate a background task
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Background Task Completed!";
        }

        @Override
        protected void onPostExecute(String result) {
            // This method is executed on the UI thread after the background task is finished
            super.onPostExecute(result);
            resultTextView.setText(result);
        }
    }
}

