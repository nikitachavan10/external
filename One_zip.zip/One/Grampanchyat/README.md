# Digital-India
This is a responsive website on the topic Digital India created using HTML, CSS and Bootstrap Framework.
You can see this live here: https://thepranaygupta.github.io/Digital-India/

## Desktop-Screenshots
![screenshot](screenshots/1.png)
![screenshot](screenshots/2.png)
![screenshot](screenshots/3.png)
![screenshot](screenshots/4.png)
![screenshot](screenshots/5.png)
![screenshot](screenshots/6.png)
![screenshot](screenshots/7.png)
![screenshot](screenshots/8.png)
![screenshot](screenshots/9.png)

## Mobile-Screenshots
![screenshot](screenshots/a.png)
![screenshot](screenshots/b.png)
![screenshot](screenshots/c.png)
![screenshot](screenshots/d.png)
![screenshot](screenshots/e.png)
![screenshot](screenshots/f.png)
![screenshot](screenshots/g.png)
![screenshot](screenshots/h.png)
![screenshot](screenshots/i.png)

### Thanks
