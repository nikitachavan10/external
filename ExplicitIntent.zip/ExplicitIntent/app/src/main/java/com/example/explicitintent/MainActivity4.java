package com.example.explicitintent;

import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }

    public void newScreen(View view) {
        Intent i = new Intent(getApplicationContext(), MainActivity5.class);
        startActivity(i);
    }
}