package com.example.recyclerviewdemo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.jetbrains.annotations.NotNull;

public class RecAdapter extends RecyclerView.Adapter <RecAdapter.RecViewHolder> {

    @NonNull
    @NotNull
    @Override
    public RecAdapter.RecViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        Context c = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(c);
        View studentView = inflater.inflate(R.layout.studentlist, parent, false);
        RecViewHolder vh = new RecViewHolder(studentView);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull RecAdapter.RecViewHolder holder, int position) {
        holder.t2.setText("1");
        holder.t3.setText("nikita");
        holder.t4.setText("nikita@gmail.com");
        holder.t5.setText("-------------------------------------------------------------------------------------------------");
    }

    @Override
    public int getItemCount() {
        return 50;
    }

    public class RecViewHolder extends RecyclerView.ViewHolder{
        TextView t2, t3, t4, t5;
        public RecViewHolder(View itemView) {
            super(itemView);
            t2=itemView.findViewById(R.id.textView2);
            t3=itemView.findViewById(R.id.textView3);
            t4=itemView.findViewById(R.id.textView4);
            t5=itemView.findViewById(R.id.textView5);
        }
    }
}
